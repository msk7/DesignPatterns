var OOPHelper = require('./OOPHelper.js');
var IStorageDevice = require('./IStorageDevice.js')
var HardDrive = require('./HardDrive.js');
var FlashDrive = require('./FlashDrive.js');
var CDDrive = require('./CDDrive.js');

var StorageDeviceFactory = {
	createStorageDevice: function(type, capacity) {

		var _storageDevice;

		switch (type.toLowerCase()) {
			case 'flashdrive':
				_storageDevice = new FlashDrive(capacity);
				break;
			case 'harddrive':
				_storageDevice = new HardDrive(capacity);
				break;
			case 'cd':
				_storageDevice = new CDDrive(capacity);
				break;
			default:
				throw new Error("Unknown StorageDevice type");
		}

		OOPHelper.Interface.ensureImplements(_storageDevice, IStorageDevice);
		return _storageDevice;				
	}
};

module.exports = StorageDeviceFactory;
