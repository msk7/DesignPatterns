var dataStructures = {
    stack : function() {                  
        var elements;
        
        this.push = function(element) {
            if (typeof(elements) === 'undefined') {
                elements = [];   
            }                            
            elements.push(element);
        };

        this.pop = function() {
            return elements.pop();
        };

        this.stackTop = function(element) {
            return elements[elements.length - 1];
        };

        this.isEmpty = function() {
            return (typeof(elements) === 'undefined') || (elements.length == 0);
        };

        // Constructor code
        return this;
    }
}

module.exports = dataStructures;