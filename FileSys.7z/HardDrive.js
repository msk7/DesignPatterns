var StorageDeviceAbstract = require('./StorageDeviceAbstract.js');
var OOPHelper = require('./OOPHelper.js');


function HardDrive(capacity) {
	HardDrive.superclass.constructor.call(this, capacity);	

	// Public (Privileged) methods
	this.GetType = function() {
		return "HardDrive";
	}
}
OOPHelper.Extend(HardDrive, StorageDeviceAbstract);


HardDrive.prototype.toString = function() {
	return "["+this.GetType()+": Capacity: "+this.GetCapacity()+"]";
}

module.exports = HardDrive;