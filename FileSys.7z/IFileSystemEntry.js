
var OOPHelper = require('./OOPHelper.js');

var IFileSystemEntry = new OOPHelper.Interface('IFileSystemEntry', ['Add','Remove','GetName','GetSize','GetChildren','GetDirectory']);

module.exports = IFileSystemEntry;