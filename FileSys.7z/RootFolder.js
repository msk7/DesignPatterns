
var IFileSysEntry = require('./IFileSysEntry.js');

var RootFolder = function() {
	
	// body...
}