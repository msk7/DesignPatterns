
var OOPHelper = require('./OOPHelper.js');

var IIterator = new OOPHelper.Interface('IIterator', ['Reset','Next','HasNext', 'Current']);

module.exports = IIterator;