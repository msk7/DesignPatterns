
var FileSystem = require('./FileSystem.js');
var OOPHelper = require('./OOPHelper.js');
var IFileSystemEntry = require('./IFileSystemEntry.js')
var StorageDeviceFactory = require('./StorageDeviceFactory');


// Create a 1GB HardDrive device
var hardDrive = StorageDeviceFactory.createStorageDevice('HardDrive', 1024*1024*1024);
console.log(hardDrive.toString());

// Add folders and files
for (folderIdx = 1; folderIdx < 3; folderIdx++) {
	var folder = hardDrive.GetRoot().Add(new FileSystem.FolderEntry('Folder-'+folderIdx));
	for (fileIdx = 1; fileIdx < 5; fileIdx++) {
		folder.Add(new FileSystem.FileEntry('File-'+fileIdx+".txt", fileIdx*1000));
	}
}

// Traverse & Display directory using callback 
hardDrive.GetRoot().GetDirectory(0, function(entry) {
	console.log(entry);
});

// Traverse and dislay using iterator
hardDrive.GetRoot().Reset();
while (hardDrive.GetRoot().HasNext())
{
	console.log(hardDrive.GetRoot().Next().toString());
}

// Create a 1MB Flash Drive drive 
var usb = StorageDeviceFactory.createStorageDevice("FlashDrive", 1024*1024);
console.log(usb.toString());

// Add a deep directory to the device
var  parent = usb.GetRoot();
for (i = 1; i < 10; i++) {
	parent = parent.Add(new FileSystem.FolderEntry('0'+i));
}
// Add a file
parent.Add(new FileSystem.FileEntry('index.html', 1024));

// Traverse & Display directory using callback 
usb.GetRoot().GetDirectory(0, function(entry) {
	console.log(entry);
});

