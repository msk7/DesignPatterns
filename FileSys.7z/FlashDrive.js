var StorageDeviceAbstract = require('./StorageDeviceAbstract.js');
var OOPHelper = require('./OOPHelper.js');

function FlashDrive(capacity) {
	FlashDrive.superclass.constructor.call(this, capacity);	

	// Public (Privileged) methods
	this.GetType = function() {
		return "FlashDrive";
	}
}
OOPHelper.Extend(FlashDrive, StorageDeviceAbstract);


FlashDrive.prototype.toString = function() {
	return "["+this.GetType()+": Capacity: "+this.GetCapacity()+"]";
}

module.exports = FlashDrive;