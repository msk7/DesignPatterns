
var OOPHelper = require('./OOPHelper.js');

var IStorageDevice = new OOPHelper.Interface('IStorageDevice', ['GetType','GetCapacity','GetIsReadOnly','GetRoot']);

module.exports = IStorageDevice;