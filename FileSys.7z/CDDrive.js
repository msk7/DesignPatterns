var StorageDeviceAbstract = require('./StorageDeviceAbstract.js');
var OOPHelper = require('./OOPHelper.js');


function CDDrive(capacity) {
	var _IsFinalized = false;

	CDDrive.superclass.constructor.call(this, capacity);	
}
OOPHelper.Extend(CDDrive, StorageDeviceAbstract);

CDDrive.prototype.GetType = function() {
	return "CD";
}

CDDrive.prototype.GetIsReadOnly = function() {
	return this._isFinalized;
}

module.exports = CDDrive;